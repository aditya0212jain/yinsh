
#!/bin/bash

## Compile our two program files
g++ -o PumpkinPie ourPlayer.cpp startOurPlayer.cpp ourGame.cpp utils.cpp -w -std=c++11